-- -------- < aula10extra1 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 16/05/2024
-- Autor(es) ..............: Gabryel Nicolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
--
-- Ultimas Alteracoes
--   16/05/2024 => criacao da base de dados e consultas
--
-- ---------------------------------------------------------

USE aula10extra1;

-- A)
SELECT sigla, nome
  FROM ESTADO
 WHERE sigla = 'SP'
   AND sigla = 'DF';

-- B)
	  SELECT CIDADE.nome, CIDADE.sigla
      FROM CIDADE
INNER JOIN ESTADO ON CIDADE.sigla = ESTADO.sigla
     WHERE sigla = 'RJ'
       AND sigla = 'DF'
       AND sigla = 'GO';

-- C)
SELECT CIDADE.nome, ESTADO.nome AS nome_estado, CIDADE.sigla
  FROM ESTADO, CIDADE
 WHERE CIDADE.sigla = (SELECT MIN(sigla) FROM ESTADO)
   AND CIDADE.sigla = ESTADO.sigla;
   AND ESTADO.sigla = 'RJ'

-- D)
  SELECT ESTADO.nome, CIDADE.nome, CIDADE.habitantes
    FROM ESTADO, CIDADE
   WHERE ESTADO.sigla = (SELECT MAX(sigla) FROM ESTADO)
     AND CIDADE.sigla = ESTADO.sigla
     AND ESTADO.sigla = 'GO'
ORDER BY ESTADO.nome ASC, CIDADE.nome DESC;

