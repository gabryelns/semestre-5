-- -------- < aula10extra1 > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 16/05/2024
-- Autor(es) ..............: Gabryel Nicolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
--
-- Ultimas Alteracoes
--   16/05/2024 => criacao da base de dados a delecao
--
-- ---------------------------------------------------------

USE aula10extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;
