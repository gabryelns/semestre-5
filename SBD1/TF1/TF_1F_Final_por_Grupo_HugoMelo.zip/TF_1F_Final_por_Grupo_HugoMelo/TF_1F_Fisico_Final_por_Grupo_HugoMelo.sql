-- -------- < Cosmeticos > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 23/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa,
-- ........................: Caio Felipe Rocha Rodrigues,
-- ........................: Danilo Cesar Tertuliano Melo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1F_hugomelo
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 02 Perfis (role)
--         => 04 Usuarios
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------


CREATE DATABASE IF NOT EXISTS TF_1F_hugomelo;
USE TF_1F_hugomelo;

CREATE TABLE TIPOPRODUTO (
    idTipoProduto DECIMAL(9) NOT NULL,
    nome VARCHAR(128) NOT NULL,
    descricao VARCHAR(256),
    CONSTRAINT TIPOPRODUTO_PK PRIMARY KEY (idTipoProduto)
)  ENGINE=INNODB;

CREATE TABLE TIPOPAGAMENTO (
    idPagamento DECIMAL(2) NOT NULL,
    forma VARCHAR(50) NOT NULL,
    CONSTRAINT TIPOPAGAMENTO_PK PRIMARY KEY (idPagamento),
    CONSTRAINT TIPOPAGAMENTO_UK UNIQUE (forma)
)  ENGINE=INNODB;

CREATE TABLE MARCA (
    idMarca DECIMAL(9) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    CONSTRAINT MARCA_PK PRIMARY KEY (idMarca)
)  ENGINE=INNODB;

CREATE TABLE CLIENTE (
    cidade VARCHAR(64),
    bairro VARCHAR(64),
    logradouro VARCHAR(64),
    complemento VARCHAR(125),
    nome VARCHAR(256) NOT NULL,
    idCliente DECIMAL(9) NOT NULL,
    CONSTRAINT CLIENTE_PK PRIMARY KEY (idCliente)
)  ENGINE=INNODB;

CREATE TABLE PRODUTO (
    idProduto DECIMAL(9) NOT NULL,
    nome VARCHAR(256) NOT NULL,
    descricao VARCHAR(125),
    idTipoProduto DECIMAL(9) NOT NULL,
    idMarca DECIMAL(9) NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY (idProduto),
    CONSTRAINT PRODUTO_TIPOPRODUTO_FK FOREIGN KEY (idTipoProduto)
        REFERENCES TIPOPRODUTO (idTipoProduto)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT PRODUTO_MARCA_FK FOREIGN KEY (idMarca)
        REFERENCES MARCA (idMarca)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT PRODUTO_UK UNIQUE (nome , idTipoProduto , idMarca)
)  ENGINE=INNODB;

CREATE TABLE PEDIDO (
    idPedido DECIMAL(9) NOT NULL,
    dataPedido DATE NOT NULL,
    codigoPedido VARCHAR(64) NOT NULL,
    valorTaxa DECIMAL(6,2) DEFAULT 0.0,
    CONSTRAINT PEDIDO_PK PRIMARY KEY (idPedido),
    CONSTRAINT PEDIDO_UK UNIQUE (codigoPedido)
) ENGINE=InnoDB;

CREATE TABLE COMPRA (
    idCompra DECIMAL(9) NOT NULL,
    dataCompra DATE NOT NULL,
    qtdParcelas DECIMAL(3) DEFAULT 1,
    taxaPorcentagem DECIMAL(2) DEFAULT 0,
    idCliente DECIMAL(9) NOT NULL,
    idPagamento DECIMAL(2) NOT NULL,
    CONSTRAINT COMPRA_PK PRIMARY KEY (idCompra),
    CONSTRAINT COMPRA_CLIENTE_FK FOREIGN KEY (idCliente)
        REFERENCES CLIENTE (idCliente)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT COMPRA_TIPOPAGAMENTO_FK FOREIGN KEY (idPagamento)
        REFERENCES TIPOPAGAMENTO (idPagamento)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE ITEM (
    validade DATE NOT NULL,
    idItem DECIMAL(9) NOT NULL,
    preco DECIMAL(6 , 2 ) NOT NULL,
    idProduto DECIMAL(9) NOT NULL,
    idPedido DECIMAL(9) NOT NULL,
    precoVenda DECIMAL(6 , 2 ),
    idCompra DECIMAL(9),
    CONSTRAINT ITEM_PK PRIMARY KEY (idItem),
    CONSTRAINT ITEM_PRODUTO_FK FOREIGN KEY (idProduto)
        REFERENCES PRODUTO (idProduto)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT ITEM_PEDIDO_FK FOREIGN KEY (idPedido)
        REFERENCES PEDIDO (idPedido)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT ITEM_COMPRA_FK FOREIGN KEY (idCompra)
        REFERENCES COMPRA (idCompra)
)  ENGINE=INNODB;

CREATE TABLE telefone (
    idCliente DECIMAL(9) NOT NULL,
    ddd DECIMAL(2) NOT NULL,
    numero DECIMAL(9) NOT NULL,
    CONSTRAINT telefone_UK UNIQUE (idCliente , ddd , numero),
    CONSTRAINT telefone_CLIENTE_FK FOREIGN KEY (idCliente)
        REFERENCES CLIENTE (idCliente)
        ON DELETE RESTRICT ON UPDATE CASCADE
)  ENGINE=INNODB;
