-- -------- < Cosmeticos > --------
--
--                    SCRIPT DE CONTROLE (DDL)
--
-- Data Criacao ...........: 23/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa,
-- ........................: Caio Felipe Rocha Rodrigues,
-- ........................: Danilo Cesar Tertuliano Melo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1F_hugomelo
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 02 Perfis (role)
--         => 04 Usuarios
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE TF_1F_hugomelo;

CREATE ROLE 'revendedor', 'administrador';
GRANT SELECT, INSERT ON TF_1F_hugomelo.* TO 'revendedor';
GRANT ALL PRIVILEGES ON TF_1F_hugomelo.* TO 'administrador';

CREATE USER 'leticia'
	IDENTIFIED BY 'password123';
GRANT 'revendedor' TO 'leticia'
	WITH ADMIN OPTION;
    
CREATE USER 'joao'
	IDENTIFIED BY 'joao12';
GRANT 'revendedor' TO 'joao';

CREATE USER 'maria'
	IDENTIFIED BY 'devpassion';
GRANT 'administrador' TO 'maria';

CREATE USER 'lucas'
	IDENTIFIED BY 'senhadific123';
GRANT 'revendedor' TO 'lucas';
