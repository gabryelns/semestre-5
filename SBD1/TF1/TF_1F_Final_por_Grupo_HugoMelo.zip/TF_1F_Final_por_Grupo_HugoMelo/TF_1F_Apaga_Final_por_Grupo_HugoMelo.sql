-- -------- < Cosmeticos > --------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 23/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa,
-- ........................: Caio Felipe Rocha Rodrigues,
-- ........................: Danilo Cesar Tertuliano Melo
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1F_hugomelo
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
--         => 02 Perfis (role)
--         => 04 Usuarios
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE TF_1F_hugomelo;

DROP TABLE telefone;
DROP TABLE ITEM;
DROP TABLE COMPRA;
DROP TABLE PEDIDO;
DROP TABLE PRODUTO;
DROP TABLE CLIENTE;
DROP TABLE MARCA;
DROP TABLE TIPOPAGAMENTO;
DROP TABLE TIPOPRODUTO;
