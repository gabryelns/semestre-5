-- -------- < cosmeticos > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 16/05/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- Ultimas Alteracoes
--      => 14/06/2024 adicionando tabelas possui, PEDIDO, TIPOPAGAMENTO e alterando relacionamento
--      de CLIENTE com PEDIDO
--      => 15/06/2024 passando atributos com INT para DECIMAL 
--      => 15/06/2024 adicionando regras para as chaves estrangeiras
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
  IF NOT EXISTS cosmeticos;

USE cosmeticos;

CREATE TABLE MARCA (
    idMarca DECIMAL(9) NOT NULL,
    nome VARCHAR(30) NOT NULL,
    CONSTRAINT MARCA_PK PRIMARY KEY (idMarca)
) ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    codigoProduto DECIMAL(9) NOT NULL,
    idMarca DECIMAL(9) NOT NULL,
    nome VARCHAR(45) NOT NULL,
    descricao VARCHAR(125) NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY (codigoProduto),
    CONSTRAINT PRODUTO_FK FOREIGN KEY (idMarca) REFERENCES MARCA (idMarca)
            ON DELETE RESTRICT
            ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE CLIENTE (
    idCliente DECIMAL(9) NOT NULL,
    nomeCompleto VARCHAR(45) NOT NULL,
    logradouro VARCHAR(50),
    cep DECIMAL(8),
    cidade VARCHAR(30),
    complemento VARCHAR(125),
    CONSTRAINT CLIENTE_PK PRIMARY KEY (idCliente)
) ENGINE = InnoDB;

CREATE TABLE telefone (
    idCliente DECIMAL(9) NOT NULL,
    telefone DECIMAL(11) NOT NULL,
    CONSTRAINT TELEFONE_UK UNIQUE (idCliente, telefone),
    CONSTRAINT TELEFONE_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente)
            ON DELETE CASCADE
            ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE LOTE (
    codigoProduto DECIMAL(9) NOT NULL,
    unidades DECIMAL(3) NOT NULL,
    precoCompra DECIMAL(6,2) NOT NULL,
    dataCompra DATE NOT NULL,
    validade DATE NOT NULL,
    CONSTRAINT LOTE_PK PRIMARY KEY (dataCompra, codigoProduto),
    CONSTRAINT LOTE_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO (codigoProduto)
            ON DELETE RESTRICT
            ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE TIPOPAGAMENTO (
    idTipo DECIMAL(2) NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    CONSTRAINT TIPOPAGAMENTO_PK PRIMARY KEY (idTipo)
) ENGINE = InnoDB;

CREATE TABLE PEDIDO (
    idCliente DECIMAL(9) NOT NULL,
    dataVenda DATE NOT NULL,
    precoVenda DECIMAL(6,2) NOT NULL,
    precoCompra DECIMAL(6,2) NOT NULL,
    pagamento DECIMAL(2) NOT NULL,
    CONSTRAINT PEDIDO_PK PRIMARY KEY (idCliente, dataVenda),
    CONSTRAINT PEDIDO_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente)
            ON DELETE RESTRICT
            ON UPDATE CASCADE,
    CONSTRAINT PEDIDO_TIPOPAGAMENTO_FK FOREIGN KEY (pagamento) REFERENCES TIPOPAGAMENTO (idTipo)
            ON DELETE RESTRICT
            ON UPDATE CASCADE   
) ENGINE = InnoDB;

CREATE TABLE possui (
    codigoProduto DECIMAL(9) NOT NULL,
    dataVenda DATE NOT NULL,
    idCliente DECIMAL(9) NOT NULL,
    CONSTRAINT POSSUI_PEDIDO_FK FOREIGN KEY (idCliente, dataVenda) REFERENCES PEDIDO (idCliente, dataVenda)
            ON DELETE RESTRICT
            ON UPDATE CASCADE,
    CONSTRAINT POSSUI_PRODUTO_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO (codigoProduto)
            ON DELETE RESTRICT
            ON UPDATE CASCADE
) ENGINE = InnoDB;
