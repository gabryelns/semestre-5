-- -------- < cosmeticos > --------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 15/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE cosmeticos;

INSERT INTO MARCA (idMarca, nome) VALUES
(1, 'Natura'),
(2, 'Avon'),
(3, 'O Boticário'),
(4, 'Eudora'),
(5, 'Mary Kay');

INSERT INTO PRODUTO (codigoProduto, idMarca, nome, descricao) VALUES
(1, 1, 'Hidratante Corporal', 'Hidratante com fragrância de baunilha'),
(2, 1, 'Perfume Amadeirado', 'Perfume com notas amadeiradas'),
(3, 2, 'Batom Vermelho', 'Batom vermelho de longa duração'),
(4, 2, 'Rímel', 'Máscara para cílios'),
(5, 3, 'Shampoo', 'Shampoo para cabelos oleosos'),
(6, 3, 'Condicionador', 'Condicionador para todos os tipos de cabelo'),
(7, 4, 'Creme Facial', 'Creme facial anti-idade'),
(8, 4, 'Protetor Solar', 'Protetor solar FPS 50'),
(9, 5, 'Base Líquida', 'Base líquida de alta cobertura'),
(10, 5, 'Demaquilante', 'Demaquilante bifásico');

INSERT INTO CLIENTE (idCliente, nomeCompleto, logradouro, cep, cidade, complemento) VALUES
(1, 'Ana Silva', 'QS 01 Rua 210, 123', 72000001, 'Taguatinga', 'Apt 101'),
(2, 'Bruno Pereira', 'SQN 404, Bloco A', 70740400, 'Asa Norte', 'Apt 202'),
(3, 'Carla Souza', 'QR 203 Conjunto 5, Casa 10', 72301500, 'Samambaia', null),
(4, 'Diego Santos', 'CLN 108, Bloco B', 70710800, 'Asa Norte', 'Sala 305'),
(5, 'Elisa Costa', 'QNA 20, Lote 05', 72100020, 'Taguatinga', 'Apt 301'),
(6, 'Fábio Almeida', 'QR 305 Conjunto 8, Casa 14', 72303500, 'Samambaia', null);

INSERT INTO telefone (idCliente, telefone) VALUES
(1, 61987654321),
(1, 61987654322),
(2, 61987654323),
(3, 61987654324),
(4, 61987654325),
(5, 61987654326),
(6, 61987654327);

INSERT INTO LOTE (codigoProduto, unidades, precoCompra, dataCompra, validade) VALUES
(1, 50, 25.00, '2023-01-10', '2025-01-10'),
(2, 30, 50.00, '2023-02-15', '2025-02-15'),
(3, 100, 10.00, '2023-03-20', '2024-03-20'),
(4, 75, 15.00, '2023-04-25', '2024-04-25'),
(5, 60, 20.00, '2023-05-30', '2025-05-30'),
(6, 40, 22.00, '2023-06-10', '2025-06-10'),
(7, 80, 30.00, '2023-07-15', '2024-07-15');

INSERT INTO TIPOPAGAMENTO (idTipo, tipo) VALUES
(1, 'Cartão de Crédito'),
(2, 'Cartão de Débito'),
(3, 'Dinheiro'),
(4, 'Boleto Bancário'),
(5, 'Pix');

INSERT INTO PEDIDO (idCliente, dataVenda, precoVenda, precoCompra, pagamento) VALUES
(1, '2024-01-05', 60.00, 50.00, 1),
(2, '2024-02-10', 40.00, 30.00, 2),
(3, '2024-03-15', 75.00, 60.00, 3),
(4, '2024-04-20', 90.00, 70.00, 4),
(5, '2024-05-25', 120.00, 100.00, 5),
(6, '2024-06-30', 55.00, 45.00, 1),
(1, '2024-07-05', 80.00, 60.00, 2);

INSERT INTO possui (codigoProduto, dataVenda, idCliente) VALUES
(1, '2024-01-05', 1),
(3, '2024-02-10', 2),
(5, '2024-03-15', 3),
(7, '2024-04-20', 4),
(9, '2024-05-25', 5),
(2, '2024-06-30', 6),
(4, '2024-07-05', 1);
