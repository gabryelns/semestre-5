-- -------- < cosmeticos > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 16/05/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

CREATE ROLE administrador;
GRANT ALL PRIVILEGES ON cosmeticos.* TO administrador
WITH GRANT OPTION;
GRANT CREATE USER ON *.* to administrador
WITH GRANT OPTION;

CREATE ROLE vendedor;
GRANT SELECT, INSERT, UPDATE, DELETE ON cosmeticos.lote TO vendedor;
GRANT SELECT, INSERT, UPDATE ON cosmeticos.produto TO vendedor;
GRANT SELECT, INSERT, UPDATE ON cosmeticos.pedido TO vendedor;
GRANT SELECT, INSERT, UPDATE, DELETE ON cosmeticos.cliente TO vendedor;
GRANT SELECT, INSERT, UPDATE, DELETE ON cosmeticos.telefone TO vendedor;
WITH GRANT OPTION;

CREATE USER lucas IDENTIFIED BY 'luc4s';
GRANT administrador TO lucas;

CREATE USER admin IDENTIFIED BY 'admin';
GRANT administrador TO admin;

CREATE USER leticia IDENTIFIED BY 'let1c14';
GRANT vendedor TO leticia;

CREATE USER ajudante IDENTIFIED BY '4jud4n7e';
GRANT vendedor TO leticia;

FLUSH PRIVILEGES;
