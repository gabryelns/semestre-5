-- -------- < cosmeticos > --------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ...........: 15/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
--
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE cosmeticos;

DROP TABLE possui;
DROP TABLE PEDIDO;
DROP TABLE telefone;
DROP TABLE LOTE;
DROP TABLE PRODUTO;
DROP TABLE CLIENTE;
DROP TABLE TIPOPAGAMENTO;
DROP TABLE MARCA;
