-- -------- < cosmeticos > --------
--
--                    SCRIPT DE REMOCAO (DDL)
--
-- Data Criacao ...........: 03/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE cosmeticos;

DROP TABLE compra;
DROP TABLE telefone;
DROP TABLE CLIENTE;
DROP TABLE LOTE;
DROP TABLE PRODUTO;
DROP TABLE MARCA;
