-- -------- < cosmeticos > --------
--
--                    SCRIPT DE POPULA (DML)
--
-- Data Criacao ...........: 03/06/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- Ultimas Alteracoes
--
-- ---------------------------------------------------------

USE cosmeticos;

INSERT INTO MARCA (idMarca, nome) VALUES
(1, 'O Boticário'),
(2, 'Natura'),
(3, 'Avon'),
(4, 'Mary Kay'),
(5, 'Jequiti');

INSERT INTO PRODUTO (codigoProduto, nome, descricao, idMarca) VALUES
(101, 'Perfume Malbec', 'Perfume amadeirado, 100ml', 1),
(102, 'Ekos Açaí', 'Creme hidratante corporal, 200ml', 2),
(103, 'Batom Ultra Color', 'Batom de longa duração, vermelho', 3),
(104, 'Base TimeWise', 'Base líquida matte, 30ml', 4),
(105, 'Perfume Riqueza', 'Perfume floral, 100ml', 5);

INSERT INTO LOTE (dataCompra, unidades, precoCompra, validade, codigoProduto) VALUES
('2023-01-10', 50, 120.00, '2025-01-10', 101),
('2023-02-15', 30, 80.00, '2025-02-15', 102),
('2023-03-20', 100, 25.00, '2024-03-20', 103),
('2023-04-25', 40, 70.00, '2025-04-25', 104),
('2023-05-30', 60, 110.00, '2025-05-30', 105);

INSERT INTO CLIENTE (idCliente, nomeCompleto, logradouro, cep, cidade) VALUES
(1, 'Ana Paula Silva', 'Rua das Flores, 123', 12345678, 'São Paulo'),
(2, 'Carlos Eduardo Oliveira', 'Avenida Brasil, 456', 23456789, 'Rio de Janeiro'),
(3, 'Mariana Rodrigues', 'Praça das Américas, 789', 34567890, 'Belo Horizonte'),
(4, 'Fernanda Almeida', 'Rua dos Girassóis, 321', 45678901, 'Porto Alegre'),
(5, 'João Pedro Santos', 'Alameda dos Anjos, 654', 56789012, 'Curitiba');

INSERT INTO telefone (idCliente, telefone) VALUES
(1, 11987654321),
(2, 21987654321),
(3, 31987654321),
(4, 51987654321),
(5, 41987654321);

INSERT INTO compra (idCliente, codigoProduto, dataVenda, precoVenda, precoCompra) VALUES
(1, 101, '2023-06-01', 150.00, 120.00),
(2, 102, '2023-06-02', 100.00, 80.00),
(3, 103, '2023-06-03', 30.00, 25.00),
(4, 104, '2023-06-04', 90.00, 70.00),
(5, 105, '2023-06-05', 130.00, 110.00);

