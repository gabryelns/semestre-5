-- -------- < cosmeticos > --------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 16/05/2024
-- Autor(es) ..............: Hugo Queiroz Camelo de Melo,
-- ........................: GabryeL Nícolas Soares de Sousa
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: cosmeticos
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
--
-- Ultimas Alteracoes
--   
--
-- ---------------------------------------------------------

-- BASE DE DADOS
CREATE DATABASE
  IF NOT EXISTS cosmeticos;

USE cosmeticos;

CREATE TABLE MARCA (
    idMarca INT NOT NULL,
    nome VARCHAR(30) NOT NULL,
    
	CONSTRAINT MARCA_PK PRIMARY KEY (idMarca)

)ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    codigoProduto INT NOT NULL,
    nome VARCHAR(45) NOT NULL,
    descricao VARCHAR(100),
    idMarca INT NOT NULL,
    
	CONSTRAINT PRODUTO_FK FOREIGN KEY (idMarca) REFERENCES MARCA (idMarca),
    CONSTRAINT PRODUTO_PK PRIMARY KEY (codigoProduto)

)ENGINE = InnoDB;

CREATE TABLE CLIENTE (
    idCliente INT NOT NULL,
    nomeCompleto VARCHAR(30) NOT NULL,
    logradouro VARCHAR(50),
    cep INT,
    cidade VARCHAR(30),
    
    CONSTRAINT CLIENTE_PK PRIMARY KEY (idCliente)
)ENGINE = InnoDB;

CREATE TABLE LOTE (
    dataCompra DATE NOT NULL,
    unidades INT NOT NULL,
    precoCompra DECIMAL(6,2) NOT NULL,
    validade DATE NOT NULL,
    codigoProduto INT NOT NULL,
    
	CONSTRAINT LOTE_PK PRIMARY KEY (dataCompra, codigoProduto),
    CONSTRAINT LOTE_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO (codigoProduto)

)ENGINE = InnoDB;

CREATE TABLE telefone (
    idCliente INT NOT NULL,
    telefone DECIMAL(11) NOT NULL,
    
    CONSTRAINT LOTE_UK UNIQUE (idCliente, telefone),
    CONSTRAINT telefone_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente)
    
)ENGINE = InnoDB;

CREATE TABLE compra (
    idCliente INT NOT NULL,
    codigoProduto INT NOT NULL,
    dataVenda DATE NOT NULL,
    precoVenda DECIMAL(6,2) NOT NULL,
    precoCompra DECIMAL(6,2) NOT NULL,
    
    CONSTRAINT compra_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente),
    CONSTRAINT compra_PRODUTO_FK FOREIGN KEY (codigoProduto) REFERENCES PRODUTO (codigoProduto)
    
)ENGINE = InnoDB;
